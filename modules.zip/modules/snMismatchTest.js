const request = require('request-promise-native');

//TODO: rename fn and file

// Do the post to get the executionId and the jsessionid. Return
// a promise that should resolve and supply that information.
// If an error, return ??? instead.
function snMissmatchInitial(subscriberID) {
    return request.post(
        {
            headers: {
                'wf-channel': 'appjson',
                'mechID': 'M99782',
                'correlationid': 12345,
                'content-type': 'application/x-www-form-urlencoded',
                'toAppid': 'ISAAC',
                'fromAppid': 'TSR_SSC'
            },
            url:     "https://scanr-jbosstest7.test.att.com/wfrest/rest/2/workflowExecution",
            form:    {
                workflowName: "chatBotPOC",
                subscriberID: "135882673"
            },
            'resolveWithFullResponse': true
        }).then( (res) => {
        return {
            "executionId": JSON.parse(res.body).executionId,
            "jsessionid": res.headers.jsessionid
        };
    })
        .catch(function (err) {
            console.error('snMissmatchInitial error: ', err);
        });
}

// Recursive function that calls itself until templateName  !== "no_step"
function snMissmatchPolling(initalPromise, n){
    return initalPromise.then( initialResult => {
        const r = {
            headers: {
                'wf-channel': 'appjson',
                'mechID': 'M99782',
                'correlationid': 12345,
                'content-type': 'application/x-www-form-urlencoded',
                'toAppid': 'ISAAC',
                'fromAppid': 'TSR_SSC',
                'Cookie': 'JSESSIONID=' + initialResult.jsessionid
            },
            url: "https://scanr-jbosstest7.test.att.com/wfrest/rest/2/workflowExecution" + "/" + initialResult.executionId + "/step",

        };
        return request.get(r).then( (res) => {
            let outer = JSON.parse(res);
            let inner = outer.content;
            if ( inner ) {
                outer.content = JSON.parse(inner);
            }
            return outer;
        }).then(
            (val) => {
                if ( val && val.templateName && (val.templateName === "data") ) {
                    // TODO: Check if SN match
                    return val.content.CustomData;
                } else {
                    return snMissmatchPolling(initalPromise, n + 1);
                }
            }
        ).catch(function (err) {
            console.error('error: ', err);
        });
    });
}

module.exports = snMissmatch = function (subscriberID) {
    if ( process.env.LIVE ){
    return snMissmatchPolling(snMissmatchInitial(subscriberID), 0);
    } else {
        return Promise.resolve({
            "CRMCustomerFirstName": "Abe",
            "BBNMSRGDeviceId": "00D09E-36151N044374",
            "CRMServiceAddress": "5005 EXECUTIVE PKWY UNIT 2W358COMP4,SN RMN,CA,94583",
            "CRMAccountStatus": "O",
            "G2RGDeviceID": "00D09E-36151N044567",
            "CRMCustomerLastName": "Lincoln",
            "EPICRGDeviceID": "00D09E-36151N044374",
            "snMatch": true
        });
    }
}



