var request = require('request-promise-native');

// Basic request test

function t1() {
	const r = request('http://www.google.com');
	r.then(function (htmlString) {
			console.log('htmlString:::::::::::::: ', htmlString);
		})
		.catch(function (err) {
			console.error('err', err);
		});
 }

//t1();

// Basic error test - not calling console error as far as I can tell

function t2() {
	const r = request('http://www.googlexxx123456789.com');
	r.then(function (htmlString) {
			console.log('htmlString:::::::::::::: ', htmlString);
		})
		.catch(function (err) {
			console.log('err', err);
		});
}

//t2();


// Basic post test

function t3() {
	const r = request.post(
		{
			headers: {'content-type' : 'application/x-www-form-urlencoded'},
			url:     "https://www.w3schools.com/jquery/demo_test_post.asp",
			form:    {
				name: "Donald d. Duck",
				city: "Duckburg"
			}
		});
	r.then(function (htmlString) {
			console.log('htmlString: ', htmlString);
		})
		.catch(function (err) {
			console.log('err', err);
		});
}

// t3();


// Basic post test

function t4() {
	request.post(
		{
			headers: {
				'wf-channel': 'appjson',
				'mechID': 'm80019',
				'correlationid': 12345,
				'content-type': 'application/x-www-form-urlencoded',
				'toAppid': 'ISAAC',
				'fromAppid': 'openAPIClient',
				'Jsessionid': '00009Ky-CbIuC5Ux19QoX_k29u5:18vt2ffaa:19eqspoo1:19eqspo33:18vt2fau4'
			},
			url:     "http://scanr-jbosstest7.test.att.com/wfrest/rest/2/workflowExecution",
			form:    {
				workflowName: "chatBotPOC",
				subscriberID: "100562878"
			}
		}).then( (res) => {
			console.log("res:  ", res)
			let outer = JSON.parse(res);
			var inner = outer.content;
			outer.content = JSON.parse(inner);
			console.log(JSON.stringify(outer));
			// console.log('status: ', outer.content.TestModuleList[0].SubscriberInformation.AccountStatus);
		})
		.catch(function (err) {
			console.error('error: ', err);
		});
}

//t4();

