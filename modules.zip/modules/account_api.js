const fs = require('mz/fs');

var handleAccountStatus = function(req, res) {
    var id = req.params.id;
    var fromFile;

    fs.readFile(__dirname + 't.txt', { encoding: 'utf8' })
        .then( sometext => console.log('2', sometext))
        .catch(function (error) {
            console.error('An error occurred 2', error);
        });

    // res.json({
    //     message: 'hooray! welcome to our api!!!!!!!!!', id: id
    // });
};

module.exports =
{
    handleAccountStatus: handleAccountStatus
};


