const chai = require("chai");
const expect = chai.expect;
const chaiAsPromised = require("chai-as-promised");

chai.use(chaiAsPromised);

const csi_api = require("./csi_api.js");
const validate_account_status = csi_api.validate_account_status;

describe('test validate_accosunt_status', function() {
    it('should return  account GOOD when not special code', function () {
       return expect(validate_account_status("1113456782")).to.eventually.equal("sns_event_acct_good");
    });
});

describe('test validate_account_status special codes', function() {
    it('should return "sns_event_acct_bad" when the first three are 0 and the last is 2', function () {
        return expect(validate_account_status("0003456782")).to.eventually.equal("sns_event_acct_bad");
    });
    it('should return "sns_event_aots_outage" when the first three are 0 and the last is 3', function () {
       return expect(validate_account_status("0003456783")).to.eventually.equal("sns_event_aots_outage");
    });

    it('should return a account bad when the first three are 0 and the last is 4', function () {
        return expect(validate_account_status("0003456784")).to.eventually.equal("sns_event_aots_fine");
    });
    it('should return a account bad when the first three are 0 and the last is not 2,3 or 4', function () {
        return expect(validate_account_status("0003456785")).to.eventually.equal("sns_event_acct_good");
    });
});
