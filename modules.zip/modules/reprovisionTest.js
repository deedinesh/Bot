var request = require('request-promise-native');

function reprovisionTest() {
    request.post(
        {
            headers: {
                'wf-channel': 'appjson',
                'mechID': 'm80019',
                'correlationid': 12345,
                'content-type': 'application/x-www-form-urlencoded',
                'toAppid': 'ISAAC',
                'fromAppid': 'openAPIClient',
                'Jsessionid': '00009Ky-CbIuC5Ux19QoX_k29u5:18vt2ffaa:19eqspoo1:19eqspo33:18vt2fau4'
            },
            url:     "https://scanr-jbosstest7.test.att.com/wfrest/rest/2/workflowExecution",
            form:    {
                workflowName: "chatBotReprovision",
                subscriberID: "135882673"
            }
        }).then( (res) => {
        console.log("res:  ", res)
        let outer = JSON.parse(res);
        var inner = outer.content;
        outer.content = JSON.parse(inner);
        console.log(JSON.stringify(outer));
        // console.log('status: ', outer.content.TestModuleList[0].SubscriberInformation.AccountStatus);
    })
        .catch(function (err) {
            console.error('error: ', err);
        });
}

reprovisionTest();





