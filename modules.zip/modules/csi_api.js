const request = require('request-promise-native');
const config = require('../configuration/config');

var agent_ids = new Array("ma123q", "jd123j", "vc123r", "dp123a", "ab123c", "ue123d", "dd123e", "vs123f", "rk123g", "rb123h", "um123i", "ua123k");

var get_agent_name = function(agent_id)
{
	var text = "Donovon";

	switch(agent_id)
	{
	    case "ma123q":
	        text = "Mike";
	        break;
	    case "jd123j":
	        text = "John";
	        break;
	    case "vc123r":
	        text = "Vincent";
	        break;
	    case "dp123a":
	        text = "David";
	        break;
	    case "ab123c":
	        text = "Amelia";
	        break;
	    case "ue123d":
	        text = "Ulysses";
	        break;
	    case "dd123e":
	        text = "Doug";
	        break;
	    case "vs123f":
	        text = "Veronica";
	        break;
	    case "rk123g":
	        text = "Robert";
	        break;
	    case "rb123h":
	        text = "Ron";
	        break;
	    case "jf123i" :
	        text = "Umberto";
	        break;
	    case "tc123k":
	        text = "Uluka";
	        break;
	    default:
	        text = "Max";
	}

	return text;
};

// Assuming status is(O)pen/(P)ending/(T)entative/(S)uspended so anything beside "O" means that the
// any status beside O means that the customer needs to talk to sales.

var validate_account_status = function(subscriberID) {
    console.log("subscriberID>>>>>>>>>>>>>>>>>>>>>>>>>>>", subscriberID)
    if ( /^000.*/.test(subscriberID) ) {
        return Promise.resolve(validate_account_status_dummy_case(subscriberID));
    } else {
        return request.post(
            {
                headers: {
                    'wf-channel': 'appjson',
                    'mechID': 'm80019',
                    'correlationid': 12345,
                    'content-type': 'application/x-www-form-urlencoded',
                    'toAppid': 'ISAAC',
                    'fromAppid': 'openAPIClient',
                    'Jsessionid': '00009Ky-CbIuC5Ux19QoX_k29u5:18vt2ffaa:19eqspoo1:19eqspo33:18vt2fau4'
                },
                url: config.accountStatusURL,
                form: {
                    workflowName: "chatBotPOC",
                    subscriberID: subscriberID
                }
            }).then((someText) => {
                let outer = JSON.parse(someText);
                let inner = outer.content;
                outer.content = JSON.parse(inner);
                let status = outer.content.TestModuleList[0].SubscriberInformation.AccountStatus;
                console.log("status>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: ", status);
                let statusCode = (status === "O" ? "sns_event_acct_good" : "sns_event_acct_bad");
                // TODO: FIX ABOVE to handle other values beside O
                console.log("statusCode>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: ", statusCode);
                return statusCode;
            })
            .catch(function (err) {
                console.error('error while requesting account status: ');
                return "sns_event_acct_good";
            });
    }
};

function validate_account_status_dummy_case(subscriberID) {

    switch(Number(subscriberID.slice(-1)))
    {
        case 2:
            return "sns_event_acct_bad";
        case 3:
            return "sns_event_aots_outage";
        case 4:
            return "sns_event_aots_fine";
        default:
            return "sns_event_acct_good";
    }
 }


var validate_serial_number = function(str)
{
  var x = str.endsWith("9");
  if(x)
  {
    return "sns_event_sn_invalid";
  }
  else
  {
    return "sns_event_sn_valid";
  }
};

var validate_serial_num_status = function(str)
{
    return "2_1_event_confirm_sn_no";
};

var check_aots_outage = function(str)
{
  var x = str.endsWith("6");
  if(x)
  {
    return "sns_event_aots_outage";
  }
  else
  {
    return "sns_event_aots_fine";
  }
};

var find_comptiable_rg_models = function()
{
  var aots = "AOTS" + Math.floor(100000 + Math.random() * 900000);

  return aots;
}

var generate_aots_number = function()
{
  var aots = "AOTS" + Math.floor(100000 + Math.random() * 900000);

  return aots;
}

module.exports =
{
  get_agent_name,
  validate_account_status,
  validate_serial_number,
  validate_serial_num_status,
  check_aots_outage
};
